
abstract class OfferServiceInterface{
  Future<dynamic> getOfferList(int offset);
}