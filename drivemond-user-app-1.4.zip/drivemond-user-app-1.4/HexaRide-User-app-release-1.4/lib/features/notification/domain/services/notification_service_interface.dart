abstract class NotificationServiceInterface{
  Future<dynamic> getList({int? offset = 1});
}