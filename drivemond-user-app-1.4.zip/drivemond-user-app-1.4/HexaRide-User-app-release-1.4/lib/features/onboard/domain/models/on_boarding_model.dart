class OnBoardingModel {
  String title;
  String image;

  OnBoardingModel({required this.title, required this.image});
}